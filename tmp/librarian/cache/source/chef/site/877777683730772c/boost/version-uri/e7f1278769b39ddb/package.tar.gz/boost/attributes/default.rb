default['boost']['source'] = "http://sourceforge.net/projects/boost/files/boost/1.51.0/"
default['boost']['file'] = "boost_1_51_0.tar.gz"
default['boost']['build_dir'] = "boost_1_51_0"
