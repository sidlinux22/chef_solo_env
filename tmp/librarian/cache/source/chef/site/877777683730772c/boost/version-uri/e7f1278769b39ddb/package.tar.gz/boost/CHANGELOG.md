## v1.0.0:

* [COOK-1832] - Add RHEL support (uses platform_family)

## v0.1.0:

* Current public release.
