thrift Cookbook CHANGELOG
=========================
This file is used to list changes made in each version of the thrift cookbook.


v1.2.0
------
### New Feature
- **[COOK-2046](https://tickets.opscode.com/browse/COOK-2046)** - Add RHEL support

v1.1.0
------
### New Feature
- [COOK-2871]: update thrift to 0.9.0

v1.0.0
------
- [COOK-904] - install version 0.8, requires Ubuntu 11.10
